import os
import shutil
import logging
import tensorflow.compat.v1 as tf
import fedlearner.trainer as flt
from utils import HFLModel
from config import IMAGE_SIZE, get_nn_model

ROLE = 'leader'

parser = flt.trainer_worker.create_argument_parser()
parser.add_argument('--batch-size',
                    type=int,
                    default=100,
                    help='Training batch size.')
args = parser.parse_args()
#args = parser.parse_args('--local-addr localhost:50051 \
#                 --peer-addr localhost:50052      \
#                 --data-path data/leader_train    \
#                 --mode train \
#                 --checkpoint-path log/leader/checkpoint  \
#                 --save-checkpoint-steps 10 \
#                 --export-path export/leader'.split())


def parse_fn(example):
    feature_map = dict()
    feature_map['example_id'] = tf.FixedLenFeature([], tf.string)
    feature_map['x'] = tf.FixedLenFeature([IMAGE_SIZE[0] * IMAGE_SIZE[1] * 3],
                                          tf.float32)
    feature_map['y'] = tf.FixedLenFeature([], tf.int64)
    features = tf.parse_example(example, features=feature_map)
    return features, dict(y=features.pop('y'))


def input_fn(bridge, trainer_master):
    datablock = flt.data.DataBlockLoader(args.batch_size, ROLE, bridge,
                                         trainer_master)
    dataset = datablock.make_dataset()
    dataset = dataset.map(map_func=parse_fn,
                          num_parallel_calls=tf.data.experimental.AUTOTUNE)
    return dataset


def serving_input_receiver_fn():
    feature_map = {
        "example_id":
            tf.FixedLenFeature([], tf.string),
        "x":
            tf.FixedLenFeature([IMAGE_SIZE[0] * IMAGE_SIZE[1] * 3], tf.float32),
    }
    record_batch = tf.placeholder(dtype=tf.string, name='examples')
    features = tf.parse_example(record_batch, features=feature_map)
    receiver_tensors = {'examples': record_batch}
    return tf.estimator.export.ServingInputReceiver(features, receiver_tensors)


def model_fn(model, features, labels, mode):

    x = features['x']
    x = tf.reshape(x, (-1, *IMAGE_SIZE, 3))

    #nn = get_nn_model(x.shape.as_list(), 2)
    nn = get_nn_model(x, 10)
    logits = nn(x)
    pred = tf.keras.activations.softmax(logits)

    if mode == tf.estimator.ModeKeys.PREDICT:
        return model.make_spec(mode=mode, predictions=pred)

    y = labels['y']
    loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=y,
                                                          logits=logits)
    loss = tf.math.reduce_mean(loss)
    correct = tf.nn.in_top_k(predictions=logits, targets=y, k=1)
    acc = tf.reduce_mean(input_tensor=tf.cast(correct, tf.float32))

    global_step = tf.train.get_or_create_global_step()
    logging_hook = tf.train.LoggingTensorHook(
        {
            "loss": loss,
            "acc": acc,
            "iter": global_step
        }, every_n_iter=10)

    if mode == tf.estimator.ModeKeys.EVAL:
        classes = tf.argmax(pred, axis=1)
        acc_pair = tf.metrics.accuracy(y, classes)
        return model.make_spec(mode=mode,
                               loss=loss,
                               predictions=pred,
                               eval_metric_ops={'accuracy': acc_pair},
                               evaluation_hooks=[logging_hook])

    hmodel = HFLModel(model, nn.weights)
    hmodel.weight_distribute()
    with tf.control_dependencies(model._train_ops):
        hmodel.gradient_collect()
    optimizer = tf.train.AdamOptimizer(0.001)
    train_op = hmodel.fed_avg(optimizer, loss, global_step)

    return model.make_spec(mode=mode,
                           loss=loss,
                           predictions=pred,
                           train_op=train_op,
                           training_hooks=[logging_hook])


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    current_dir = os.path.dirname(__file__)
    if args.mode == 'train':
        shutil.rmtree(os.path.join(current_dir, args.checkpoint_path),
                      ignore_errors=True)
    flt.trainer_worker.train(ROLE, args, input_fn, model_fn,
                             serving_input_receiver_fn)
