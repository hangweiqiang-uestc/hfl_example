import tensorflow.compat.v1 as tf

class HFLModel():

    def __init__(self, model, var_list=None):
        self._model = model
        self._role = model._role
        if var_list is None:
            var_list = tf.get_collection(
                tf.GraphKeys.TRAINABLE_VARIABLES) + tf.get_collection(
                    tf.GraphKeys.TRAINABLE_RESOURCE_VARIABLES)

        self._var_list = var_list
        self._trainable_var_list = [
            var for var in self._var_list if var.trainable
        ]

    @staticmethod
    def get_var_name(name):
        return name.split(':')[0]

    def weight_distribute(self):
        for var in self._var_list:
            self._model.send(self.get_var_name(var.name), var)

    def weight_collect(self):
        init_weights = []
        for var in self._var_list:
            recv_weight = self._model.recv(self.get_var_name(var.name))
            #init_weights[self.get_var_name(var.name)] = var.assign(recv_weight)
            init_weights.append(var.assign(recv_weight))
        return init_weights

    def gradient_collect(self):
        for var in self._trainable_var_list:
            self._model.recv(self.get_var_name(var.name) + '_grad')

    def gradient_send(self, loss):
        optimizer = tf.train.GradientDescentOptimizer(0.1)
        grads_and_vars = optimizer.compute_gradients(
            loss, var_list=self._trainable_var_list)
        for grad, var in grads_and_vars:
            self._model.send(self.get_var_name(var.name) + '_grad', grad)

    def fed_avg(self, optimizer, loss, global_step=None, name=None):

        recv_grads = {n: grad for n, grad, _ in self._model._recvs}
        grads_and_vars = optimizer.compute_gradients(loss,
                                                     self._trainable_var_list)
        ngrads_and_vars = []
        for grad, var in grads_and_vars:
            name = self.get_var_name(var.name) + '_grad'
            if name in recv_grads.keys():
                ngrad = recv_grads[name]
                #with tf.control_dependencies([tf.print(name, grad), tf.print('recv'+name, ngrad)]):
                grad = (grad + ngrad) / 2
            ngrads_and_vars.append((grad, var))
        train_op = optimizer.apply_gradients(ngrads_and_vars,
                                             global_step=global_step,
                                             name=name)
        return train_op
