import tensorflow.compat.v1 as tf

IMAGE_SIZE = (32, 32)


def get_conv_block(out_channels, kernel_size=3):
    conv = tf.keras.Sequential([
        tf.keras.layers.Conv2D(out_channels,
                               kernel_size,
                               strides=(1, 1),
                               padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.ReLU(),
        tf.keras.layers.Conv2D(out_channels,
                               kernel_size,
                               strides=(1, 1),
                               padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.ReLU(),
        tf.keras.layers.Conv2D(out_channels,
                               kernel_size,
                               strides=(2, 2),
                               padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.ReLU(),
    ])
    return conv


def get_nn_model(x, num_classes):
    conv1 = get_conv_block(32)
    conv2 = get_conv_block(64)
    conv3 = get_conv_block(128)
    model = tf.keras.Sequential([
        conv1, conv2, conv3,
        tf.keras.layers.GlobalAveragePooling2D(),
        tf.keras.layers.Dense(128),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.ReLU(),
        tf.keras.layers.Dense(num_classes)
    ])
    model.build(input_shape=x.shape)
    return model
