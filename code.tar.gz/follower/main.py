import logging
import tensorflow.compat.v1 as tf
import fedlearner.trainer as flt
from tensorflow.compat.v1.train import Optimizer

ROLE = 'follower'


def input_fn(bridge, trainer_master):
    dataset = flt.data.DataBlockLoader(args.batch_size, ROLE,
                                       bridge, trainer_master).make_dataset()

    def parse_fn(example):
        feature_map = dict()
        feature_map['example_id'] = tf.FixedLenFeature([], tf.string)
        feature_map['x'] = tf.FixedLenFeature([28 * 28], tf.float32)
        feature_map['y'] = tf.FixedLenFeature([], tf.int64)
        features = tf.parse_example(example, features=feature_map)
        return features, dict(y=features.pop('y'))

    dataset = dataset.map(map_func=parse_fn,
                          num_parallel_calls=tf.data.experimental.AUTOTUNE)
    return dataset


def serving_input_receiver_fn():
    feature_map = {
        "example_id": tf.FixedLenFeature([], tf.string),
        "x": tf.FixedLenFeature([28 * 28], tf.float32),
    }
    record_batch = tf.placeholder(dtype=tf.string, name='examples')
    features = tf.parse_example(record_batch, features=feature_map)
    receiver_tensors = {'examples': record_batch}
    return tf.estimator.export.ServingInputReceiver(features, receiver_tensors)


def worker_train_op(model, optimizer, loss, global_step=None,
                    var_list=None,
                    gate_gradients=Optimizer.GATE_OP,
                    aggregation_method=None,
                    colocate_gradients_with_ops=False,
                    name=None,
                    grad_loss=None):

    if var_list is None:
        var_list = [i[1] for i in model._recvs]

    grads_and_vars = optimizer.compute_gradients(
        loss,
        var_list=var_list,
        gate_gradients=gate_gradients,
        aggregation_method=aggregation_method,
        colocate_gradients_with_ops=colocate_gradients_with_ops,
        grad_loss=grad_loss,
    )

    recv_vars = model._recvs
    for (n, _, _), (grad, _) in zip(recv_vars, grads_and_vars):
        if grad is not None:
            model.send(n + '_grad', grad)
    train_op = tf.no_op(name=name)
    return train_op


def model_fn(model, features, labels, mode):
    x = features['x']
    x = tf.reshape(x, (x.shape[0], 28, 28, 1))

    conv1_kernel = model.recv('conv1_kernel', tf.float32, require_grad=True)
    conv1_bias = model.recv('conv1_bias', tf.float32, require_grad=True)
    conv2_kernel = model.recv('conv2_kernel', tf.float32, require_grad=True)
    conv2_bias = model.recv('conv2_bias', tf.float32, require_grad=True)
    dense1_kernel = model.recv('dense1_kernel', tf.float32, require_grad=True)
    dense1_bias = model.recv('dense1_bias', tf.float32, require_grad=True)
    dense2_kernel = model.recv('dense2_kernel', tf.float32, require_grad=True)
    dense2_bias = model.recv('dense2_bias', tf.float32, require_grad=True)

    with tf.control_dependencies(model._train_ops):
        conv1 = tf.nn.bias_add(tf.nn.conv2d(x, conv1_kernel, strides=2, padding='SAME'), conv1_bias)
        conv1 = tf.nn.leaky_relu(conv1)
        conv2 = tf.nn.bias_add(tf.nn.conv2d(conv1, conv2_kernel, strides=2, padding='SAME'), conv2_bias)
        conv2 = tf.nn.leaky_relu(conv2)
        latent = tf.layers.flatten(conv2)
        act1 = tf.nn.relu(tf.nn.bias_add(tf.matmul(latent, dense1_kernel), dense1_bias))
        logits = tf.nn.bias_add(tf.matmul(act1, dense2_kernel), dense2_bias)
    #pred = tf.keras.activations.softmax(logits)

    if mode == tf.estimator.ModeKeys.PREDICT:
        return model.make_spec(mode=mode, predictions=logits)

    y = labels['y']
    loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=y,
                                                          logits=logits)
    loss = tf.math.reduce_mean(loss)

    if mode == tf.estimator.ModeKeys.EVAL:
        classes = tf.argmax(logits, axis=1)
        acc_pair = tf.metrics.accuracy(y, classes)
        return model.make_spec(
            mode=mode, loss=loss, eval_metric_ops={'accuracy': acc_pair})

    optimizer = tf.train.GradientDescentOptimizer(0.001)
    global_step = tf.train.get_or_create_global_step()
    with tf.control_dependencies([global_step]):
        train_op = worker_train_op(model, optimizer, loss)
    correct = tf.nn.in_top_k(predictions=logits, targets=y, k=1)
    acc = tf.reduce_mean(input_tensor=tf.cast(correct, tf.float32))
    logging_hook = tf.train.LoggingTensorHook(
        {"loss": loss, "acc": acc}, every_n_iter=10)
    return model.make_spec(
        mode=mode, loss=loss, train_op=train_op,
        training_hooks=[logging_hook])


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    parser = flt.trainer_worker.create_argument_parser()
    parser.add_argument('--batch-size', type=int, default=64,
                        help='Training batch size.')
    args = parser.parse_args('--local-addr localhost:50052     \
                       --peer-addr localhost:50051      \
                       --data-path data/follower          \
		            --checkpoint-path log/checkpoint \
    		   --save-checkpoint-steps 10'.split())
    flt.trainer_worker.train(
        ROLE, args, input_fn,
        model_fn, serving_input_receiver_fn)
