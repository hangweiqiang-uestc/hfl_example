import logging
import tensorflow.compat.v1 as tf
import fedlearner.trainer as flt
from tensorflow.compat.v1.train import Optimizer

ROLE = 'leader'


def input_fn(bridge, trainer_master):
    dataset = flt.data.DataBlockLoader(args.batch_size, ROLE,
                                       bridge, trainer_master).make_dataset()

    def parse_fn(example):
        feature_map = dict()
        feature_map['example_id'] = tf.FixedLenFeature([], tf.string)
        feature_map['x'] = tf.FixedLenFeature([28 * 28], tf.float32)
        feature_map['y'] = tf.FixedLenFeature([], tf.int64)
        features = tf.parse_example(example, features=feature_map)
        return features, dict(y=features.pop('y'))

    dataset = dataset.map(map_func=parse_fn,
                          num_parallel_calls=tf.data.experimental.AUTOTUNE)
    return dataset


def serving_input_receiver_fn():
    feature_map = {
        "example_id": tf.FixedLenFeature([], tf.string),
        "x": tf.FixedLenFeature([28 * 28], tf.float32),
    }
    record_batch = tf.placeholder(dtype=tf.string, name='examples')
    features = tf.parse_example(record_batch, features=feature_map)
    receiver_tensors = {'examples': record_batch}
    return tf.estimator.export.ServingInputReceiver(features, receiver_tensors)


def master_train_op(model, optimizer,
                    loss,
                    global_step=None,
                    var_list=None,
                    gate_gradients=Optimizer.GATE_OP,
                    aggregation_method=None,
                    colocate_gradients_with_ops=False,
                    name=None,
                    grad_loss=None):
    recv_grads = {n: grad for n, grad, _ in model._recvs}

    if var_list is None:
        var_list = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES) + \
                   tf.get_collection(tf.GraphKeys.TRAINABLE_RESOURCE_VARIABLES)

    with tf.control_dependencies(model._train_ops):
        grads_and_vars = optimizer.compute_gradients(
            loss,
            var_list=var_list,
            gate_gradients=gate_gradients,
            aggregation_method=aggregation_method,
            colocate_gradients_with_ops=colocate_gradients_with_ops,
            grad_loss=grad_loss
        )

    ngrads_and_vars = []
    for grad, var in grads_and_vars:
        _grad = recv_grads[var.name.split(':')[0] + '_grad']
        # better to average the gradient based on the batch_size
        ngrads_and_vars.append(((grad + _grad) / 2, var))

    train_op = optimizer.apply_gradients(
        ngrads_and_vars,
        global_step=global_step,
        name=name)

    return train_op


def model_fn(model, features, labels, mode):
    x = features['x']
    x = tf.reshape(x, (x.shape[0], 28, 28, 1))

    conv1_kernel = tf.get_variable('conv1_kernel',
                                   shape=(3, 3, 1, 16),
                                   dtype=tf.float32,
                                   initializer=tf.random_uniform_initializer(-1, 1))
    conv1_bias = tf.get_variable('conv1_bias',
                                 shape=(16,),
                                 dtype=tf.float32,
                                 initializer=tf.zeros_initializer())
    conv2_kernel = tf.get_variable('conv2_kernel',
                                   shape=(3, 3, 16, 32),
                                   dtype=tf.float32,
                                   initializer=tf.random_uniform_initializer(-1, 1))
    conv2_bias = tf.get_variable('conv2_bias',
                                 shape=(32,),
                                 dtype=tf.float32,
                                 initializer=tf.zeros_initializer())

    dense1_kernel = tf.get_variable('dense1_kernel',
                                    shape=(7 * 7 * 32, 128),
                                    dtype=tf.float32,
                                    initializer=tf.random_uniform_initializer(
                                        -1, 1))
    dense1_bias = tf.get_variable('dense1_bias',
                                  shape=(128,),
                                  dtype=tf.float32,
                                  initializer=tf.zeros_initializer())
    dense2_kernel = tf.get_variable('dense2_kernel',
                                    shape=(128, 10),
                                    dtype=tf.float32,
                                    initializer=tf.random_uniform_initializer(
                                        -1, 1))
    dense2_bias = tf.get_variable('dense2_bias',
                                  shape=(10,),
                                  dtype=tf.float32,
                                  initializer=tf.zeros_initializer())

    conv1 = tf.nn.bias_add(tf.nn.conv2d(x, conv1_kernel, strides=2, padding='SAME'), conv1_bias)
    conv1 = tf.nn.leaky_relu(conv1)
    conv2 = tf.nn.bias_add(tf.nn.conv2d(conv1, conv2_kernel, strides=2, padding='SAME'), conv2_bias)
    conv2 = tf.nn.leaky_relu(conv2)
    latent = tf.layers.flatten(conv2)
    act1 = tf.nn.relu(tf.nn.bias_add(tf.matmul(latent, dense1_kernel), dense1_bias))
    logits = tf.nn.bias_add(tf.matmul(act1, dense2_kernel), dense2_bias)
    pred = tf.keras.activations.softmax(logits)

    model.send('conv1_kernel', conv1_kernel)
    model.send('conv1_bias', conv1_bias)
    model.send('conv2_kernel', conv2_kernel)
    model.send('conv2_bias', conv2_bias)
    model.send('dense1_kernel', dense1_kernel)
    model.send('dense1_bias', dense1_bias)
    model.send('dense2_kernel', dense2_kernel)
    model.send('dense2_bias', dense2_bias)
    with tf.control_dependencies(model._train_ops):
        # pass
        model.recv('conv1_kernel_grad', dtype=tf.float32, require_grad=False)
        model.recv('conv1_bias_grad', dtype=tf.float32, require_grad=False)
        model.recv('conv2_kernel_grad', dtype=tf.float32, require_grad=False)
        model.recv('conv2_bias_grad', dtype=tf.float32, require_grad=False)
        model.recv('dense1_kernel_grad', dtype=tf.float32, require_grad=False)
        model.recv('dense1_bias_grad', dtype=tf.float32, require_grad=False)
        model.recv('dense2_kernel_grad', dtype=tf.float32, require_grad=False)
        model.recv('dense2_bias_grad', dtype=tf.float32, require_grad=False)

    if mode == tf.estimator.ModeKeys.PREDICT:
        return model.make_spec(mode=mode, predictions=logits)

    y = labels['y']
    # with tf.control_dependencies([tf.print('y', y),
    #                              tf.print('conv1\n', conv1[:5, 1, 1, :6]),
    #                              tf.print('conv2\n', conv2[:5, 1, 1, :6]),
    #                              tf.print('pred\n', pred[:5])]):
    loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=y,
                                                          logits=logits)
    loss = tf.math.reduce_mean(loss)

    if mode == tf.estimator.ModeKeys.EVAL:
        classes = tf.argmax(logits, axis=1)
        acc_pair = tf.metrics.accuracy(y, classes)
        return model.make_spec(
            mode=mode, loss=loss, eval_metric_ops={'accuracy': acc_pair})

    optimizer = tf.train.GradientDescentOptimizer(0.001)
    train_op = master_train_op(model,
                               optimizer, loss, global_step=tf.train.get_or_create_global_step())
    correct = tf.nn.in_top_k(predictions=logits, targets=y, k=1)
    acc = tf.reduce_mean(input_tensor=tf.cast(correct, tf.float32))
    logging_hook = tf.train.LoggingTensorHook(
        {"loss": loss, "acc": acc}, every_n_iter=10)
    return model.make_spec(
        mode=mode, loss=loss, train_op=train_op,
        training_hooks=[logging_hook])


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    parser = flt.trainer_worker.create_argument_parser()
    parser.add_argument('--batch-size', type=int, default=64,
                        help='Training batch size.')
    args = parser.parse_args('--local-addr localhost:50051 \
                     --peer-addr localhost:50052 \
                     --data-path data/leader          \
		            --checkpoint-path log/checkpoint\
    		        --save-checkpoint-steps 10'.split())
    flt.trainer_worker.train(
        ROLE, args, input_fn,
        model_fn, serving_input_receiver_fn)
