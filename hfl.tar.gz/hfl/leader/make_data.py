# Copyright 2020 The FedLearner Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# coding: utf-8

import os
import shutil
import numpy as np
import tensorflow as tf

from tensorflow.core.example.example_pb2 import Example
from tensorflow.core.example.feature_pb2 import FloatList, Features, Feature, \
                                                Int64List, BytesList

current_dir = os.path.dirname(__file__)
shutil.rmtree(os.path.join(current_dir, 'data'), ignore_errors=True)
os.makedirs(os.path.join(current_dir, 'data/leader'))
os.makedirs(os.path.join(current_dir, 'data/follower'))

x = x.reshape(x.shape[0], -1).astype(np.float32) / 255.0
y = y.astype(np.int64)

x_leader = x[0:len(x) // 2]
y_leader = y[0:len(y) // 2]
x_follower = x[len(x) // 2:]
y_follower = y[len(y) // 2:]

N = 10
chunk_size = x_leader.shape[0] // N

for i in range(N):
    filename_leader = os.path.join(current_dir,
                                   'data/leader/%02d.tfrecord' % i)
    filename_follower = os.path.join(current_dir,
                                     'data/follower/%02d.tfrecord' % i)
    fp_leader = tf.io.TFRecordWriter(filename_leader)
    fp_follower = tf.io.TFRecordWriter(filename_follower)

    # write in N chunks
    for j in range(chunk_size):
        idx = i * chunk_size + j
        features_leader = {
            'example_id':
            Feature(bytes_list=BytesList(value=[str(idx).encode('utf-8')])),
            'y':
            Feature(int64_list=Int64List(value=[y_leader[idx]])),
            'x':
            Feature(float_list=FloatList(value=list(x_leader[idx])))
        }
        fp_leader.write(
            Example(features=Features(
                feature=features_leader)).SerializeToString())

        features_follower = {
            'example_id':
            Feature(bytes_list=BytesList(value=[str(idx).encode('utf-8')])),
            'y':
            Feature(int64_list=Int64List(value=[y_follower[idx]])),
            'x':
            Feature(float_list=FloatList(value=list(x_follower[idx])))
        }
        fp_follower.write(
            Example(features=Features(
                feature=features_follower)).SerializeToString())

    fp_follower.close()
    fp_leader.close()
